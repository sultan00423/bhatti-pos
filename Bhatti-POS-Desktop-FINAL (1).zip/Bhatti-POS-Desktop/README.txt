BHATTI POS - Desktop App (FINAL)

===== AAP (DEVELOPER) KYA KAREIN =====
1. Node.js LTS install: https://nodejs.org
2. Is folder mein BUILD-WINDOWS.bat double-click karo (internet + 5-15 min)
3. dist folder mein "Bhatti POS Setup.exe" banega
4. Sirf Setup.exe client ko do

===== CLIENT KYA KAREIN =====
1. Bhatti POS Setup.exe double-click
2. Install ho jayega
3. Desktop pe "Bhatti POS" icon aa jayega
4. Icon se open karein

===== DATA =====
PC pe save: C:\Users\<name>\AppData\Roaming\bhatti-pos
Backup: Settings > Full Backup
Restore: Settings > Restore Backup

===== RECEIPT FOOTER =====
- ہمارے یہاں پلاسٹک، اسٹیل، میلامین اور چینی کے مکمل ورائٹی ہول سیل ریٹ پر دستیاب ہیں۔
- مال گم ہونے کی صورت میں 2 دن میں اطلاع دینی شرط ہے۔
- (قبضے کسی صورت معاوضہ نہیں)
- Exchange will be possible with receipt only
