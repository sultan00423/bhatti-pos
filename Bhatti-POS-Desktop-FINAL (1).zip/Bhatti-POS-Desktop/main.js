const { app, BrowserWindow, Menu, shell } = require('electron');
const path = require('path');
if (!app.requestSingleInstanceLock()) app.quit();
let win;
function create() {
  const icon = path.join(__dirname, 'build', 'icon.png');
  win = new BrowserWindow({ width: 1366, height: 820, show: false, autoHideMenuBar: true, icon, title: 'Bhatti POS',
    webPreferences: { contextIsolation: true, nodeIntegration: false, devTools: false } });
  Menu.setApplicationMenu(null);
  win.maximize();
  win.loadFile(path.join(__dirname, 'app', 'index.html'));
  win.once('ready-to-show', () => win.show());
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https?:/i.test(url)) { shell.openExternal(url); return { action: 'deny' }; }
    return { action: 'allow', overrideBrowserWindowOptions: { autoHideMenuBar: true, icon } };
  });
}
app.on('second-instance', () => { if (win) { if (win.isMinimized()) win.restore(); win.focus(); } });
app.whenReady().then(create);
app.on('window-all-closed', () => app.quit());
