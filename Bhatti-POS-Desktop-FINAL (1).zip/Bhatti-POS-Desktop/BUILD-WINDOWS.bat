@echo off
cd /d %~dp0
call npm install
call npm run dist
echo.
echo Installer "dist" folder mein ban gaya. Usay chalao.
explorer dist
pause
